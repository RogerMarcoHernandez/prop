-------------------------------
PROP - GRUP 43 - SUBGRUP 5
-------------------------------

* Carlos Rubio, Juan juan.carlos.rubio@estudiantat.upc.edu

* Estany de Pouplana, Jordi jordi.estany.de.pouplana@estudiantat.upc.edu

* Marco Hernandez, Roger roger.marco.hernandez@estudiantat.upc.edu

* Pertusa Cuadrado, Alex alex.pertusa@estudiantat.upc.edu
