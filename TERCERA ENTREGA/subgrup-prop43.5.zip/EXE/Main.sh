cd CLASS
java Main/MainPres