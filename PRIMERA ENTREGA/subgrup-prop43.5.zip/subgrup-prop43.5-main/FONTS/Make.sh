javac --release 11 Dominio/*.java ;
javac --release 11 Drivers/*.java ;
javac --release 11 ControladoresDominio/*.java ;
javac --release 11 Excepciones/*.java ;
mv Dominio/*.class ../EXE/CLASS/Dominio ;
mv Drivers/*.class ../EXE/CLASS/Drivers ;
mv ControladoresDominio/*.class ../EXE/CLASS/ControladoresDominio ;
mv Excepciones/*.class ../EXE/CLASS/Excepciones ;