package Dominio;

import java.util.List;

public interface Maquina {
	public List<List<Integer>> solve(List<Integer> solution) throws Exception;
}