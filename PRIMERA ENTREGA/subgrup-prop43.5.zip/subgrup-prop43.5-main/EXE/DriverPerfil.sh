cd CLASS
java Drivers/DriverPerfil
